# Budget Familial & Personnel — version Android

Ce projet construit une application Android installable (APK) à partir de l'application HTML existante.

## Construction automatique sur GitHub

1. Téléverser les dossiers `app/` et `.github/`, ainsi que `build.gradle`, `settings.gradle`, `gradle.properties` et ce fichier, à la racine du dépôt GitHub existant.
2. Ouvrir l'onglet **Actions** du dépôt.
3. Sélectionner **Construire l'APK Android** puis **Run workflow** si le lancement automatique n'a pas démarré.
4. À la fin, ouvrir l'exécution réussie et télécharger l'artefact `Budget-Familial-Personnel-APK`.
5. Extraire le ZIP téléchargé : il contient `app-debug.apk`.

## Données personnelles

Les données sont conservées dans le stockage local de l'application sur le téléphone. Elles ne sont pas synchronisées avec GitHub. Faire régulièrement une sauvegarde JSON et la conserver dans un emplacement privé.

## Important

Il s'agit d'un APK de débogage signé automatiquement pour les tests et l'installation directe. Il n'est pas publié sur Google Play.
